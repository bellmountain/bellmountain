<?php 


add_filter('manage_matx-portfolio_posts_columns', 'matx_portfolios_column_head');
add_action('manage_matx-portfolio_posts_custom_column', 'matx_populate_portfolio_thumb', 10, 2);
add_filter( 'manage_edit-matx-portfolio_sortable_columns', 'matx_portfolio_column_sortable' );

/* add new column */ 

function matx_portfolios_column_head($columns) {
	unset($columns['date']);
	unset($columns['taxonomy-portfolio-category']);

    $columns['featured_image'] = esc_html__('Thumbnail', 'matx');
    $columns['taxonomy-portfolio-category'] = esc_html__('Portfolio Categories', 'matx');

    $columns['pf_type'] = esc_html__('Portfolio Type', 'matx');
    $columns['pf_attachments'] = esc_html__('Total Attachments', 'matx');
    $columns['date'] = esc_html__('Date', 'matx');

    return $columns;
}
 

/* show content into column */

function matx_populate_portfolio_thumb($column_name, $post_ID) {

	$prefix 		= '_matx_portfolio_'; 
	$extra_iamges 	= get_post_meta( $post_ID, $prefix.'attached_images', true );
	$total_atm 		= count($extra_iamges);

	$portfolio_type = get_post_meta( $post_ID, $prefix.'is_external_url', true );
	$sp_style 		= get_post_meta( $post_ID, $prefix.'single_page_style', true );


	switch ($column_name) {
		case 'featured_image':
   			( has_post_thumbnail( $post_ID )) ? the_post_thumbnail('matx-column-thumb') : ''; 
		break;

		case 'pf_type':

			switch ($portfolio_type) {

				case 'pf_ac_single':

					switch ($sp_style) {

						case 'style_two':
							$sps = 'Style 2';
						break;

						case 'value':
							$sps = 'Style 3';
						break;

						case 'value':
							$sps = 'Visual Composer';
						break;

						default:
							$sps = 'Style 1';
						break;
					}

					echo esc_html__('Details Page', 'matx').' '.esc_html__( "( $sps )", "matx" );

				break;
				
				case 'pf_ac_light':
					echo esc_html__('Lightbox Gallery', 'matx' );
					break;
				
				default:
					echo esc_html__('Details Popup', 'matx' );
				break;
			} 

		break;

		case 'pf_attachments' : 
			echo ( $total_atm > 1 ) ? '<span>'.esc_attr( $total_atm ).'</span>' : '0';
		break;
	}
}

/* make column sortable */

function matx_portfolio_column_sortable( $columns ) {
    $columns['featured_image'] = esc_html__('Thumbnail', 'matx' );
    $columns['taxonomy-portfolio-category'] = esc_html__('Portfolio Categories', 'matx' );
    $columns['pf_attachments'] = esc_html__('Total Attachments', 'matx' );
    $columns['pf_type'] = esc_html__('Portfolio Type', 'matx' );

    return $columns;
}