<?php 


add_filter('manage_matx-testimonial_posts_columns', 'matx_testimonial_column_head');
add_action('manage_matx-testimonial_posts_custom_column', 'matx_populate_testimonial_thumb', 10, 2);
add_filter( 'manage_edit-matx-testimonial_sortable_columns', 'matx_testimonial_column_sortable' );

/* add new column */
function matx_testimonial_column_head($columns) {
	unset($columns['date']);

    $columns['featured_image'] = __('Thumbnail', 'matx');
    $columns['date'] = __('Date', 'matx');

    return $columns;
}
 
/* show content into column */

function matx_populate_testimonial_thumb($column_name, $post_ID) {

	switch ($column_name) {
		case 'featured_image':
   			( has_post_thumbnail( $post_ID )) ? the_post_thumbnail('matx-column-thumb') : ''; 
		break;
	}
}

/* make custom column sortable */

function matx_testimonial_column_sortable( $columns ) {
    $columns['featured_image'] = 'Thumbnail';

    return $columns;
}