<?php 


add_filter('manage_matx-specialty_posts_columns', 'matx_specialties_column_head');
add_action('manage_matx-specialty_posts_custom_column', 'matx_populate_speciality_thumb', 10, 2);
add_filter( 'manage_edit-matx-specialty_sortable_columns', 'matx_specialties_column_sortable' );

/* add new column */
function matx_specialties_column_head($columns) {
	unset($columns['date']);
    $columns['featured_image'] = __('Thumbnail', 'matx');
    $columns['icon'] = __('Icon', 'matx');
    $columns['date'] = __('Date', 'matx');
    
    return $columns;
}
 
/* show content into column */

function matx_populate_speciality_thumb($column_name, $post_ID) {

	switch ($column_name) {
		case 'featured_image':
   			( has_post_thumbnail( $post_ID )) ? the_post_thumbnail('matx-column-thumb') : ''; 
		break;

		case 'icon' : 

	    	$prefix = '_matx_specialty_'; 
			$sp_iconclass = get_post_meta( get_the_id(), $prefix.'icon_class', true ); 	
			echo isset($sp_iconclass) ? '<i class="'.esc_attr( $sp_iconclass ).'"></i>' : '';
		break;
	}
}

/* make column sortable */

function matx_specialties_column_sortable( $columns ) {
    $columns['featured_image'] = 'team_thumb';
    $columns['icon'] = 'icon';

    return $columns;
}