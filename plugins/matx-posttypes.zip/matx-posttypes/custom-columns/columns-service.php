<?php 


add_filter('manage_matx-service_posts_columns', 'matx_service_column_head');
add_action('manage_matx-service_posts_custom_column', 'matx_populate_service_thumb', 10, 2);
add_filter( 'manage_edit-matx-service_sortable_columns', 'matx_service_column_sortable' );

/* add new column  */
function matx_service_column_head($columns) {
	unset($columns['date']);
    $columns['featured_image'] = __( 'Thumbnail', 'matx');
    $columns['icon'] = __( 'Tab Icon', 'matx');
    $columns['date'] = __( 'Date', 'matx');
    
    return $columns;
}
 
/* show content int column */

function matx_populate_service_thumb($column_name, $post_ID) {

	switch ($column_name) {
		case 'featured_image':
   			( has_post_thumbnail( $post_ID )) ? the_post_thumbnail('matx-column-thumb') : ''; 
		break;

		case 'icon' : 
	    	$prefix = '_matx_service_'; 

			$service_tab_icon = get_post_meta( $post_ID , $prefix.'tab_icon',true );

			echo isset( $service_tab_icon) ? '<i class="'.esc_attr( $service_tab_icon ).'"></i>' : '';

		break;
	}
}

/* make column sortable */

function matx_service_column_sortable( $columns ) {
    $columns['featured_image'] = 'Thumbnail';
    $columns['icon'] = 'Tab Icon';

    return $columns;
}