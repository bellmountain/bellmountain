<?php 


add_filter('manage_post_posts_columns', 'matx_post_column_head');
add_action('manage_post_posts_custom_column', 'matx_populate_post_thumb', 10, 2);
add_filter( 'manage_edit_post_sortable_columns', 'matx_post_column_sortable' );

function get_banner_img_id($image_url) {
	global $wpdb;
	$attachment = $wpdb->get_col($wpdb->prepare("SELECT ID FROM $wpdb->posts WHERE guid='%s';", $image_url )); 

	if( $attachment){
    	return $attachment[0]; 
	} 

	return false;

}

/* add new column */ 

function matx_post_column_head($columns) {
	unset($columns['date']); 
	unset($columns['author']); 
	unset($columns['categories']); 
	unset($columns['tags']); 
	unset($columns['comments']); 

    $columns['featured_image'] = __( 'Thumbnail', 'matx');
    $columns['categories'] = __( 'Categories', 'matx');
    $columns['tags'] = __( 'Tags', 'matx');
    $columns['banner'] = __( 'Banner Image', 'matx');
    $columns['author'] = __( 'Author', 'matx');
    $columns['date'] = __( 'Date', 'matx');

    return $columns;
}
 

/* show content into column */

function matx_populate_post_thumb($column_name, $post_ID) {

	switch ($column_name) {

		case 'featured_image':
   			( has_post_thumbnail( $post_ID )) ? the_post_thumbnail('matx-column-thumb') : ''; 
		break;

		case 'banner' : 
	    	$image_url = get_post_meta( $post_ID, '_matx_page_banner_background', 1 );
			$image_id = get_banner_img_id($image_url);
			if( $image_id ){
				$banner_img = wp_get_attachment_image( $image_id, 'matx-post-banner');
				echo $banner_img;
			}
		break;
	}
}

/* make column sortable */

function matx_post_column_sortable( $columns ) {
    $columns['featured_image'] = 'team_thumb';
    $columns['taxonomy-portfolio-category'] = 'Portfolio Categories';
    $columns['pf_attachments'] = 'Total Attachments';

    return $columns;
}