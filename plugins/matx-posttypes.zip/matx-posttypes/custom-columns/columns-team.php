<?php 

add_filter('manage_matx-team_posts_columns', 'matx_team_column_head');
add_action('manage_matx-team_posts_custom_column', 'matx_populate_team_thumb', 10, 2);
add_filter( 'manage_edit-matx-team_sortable_columns', 'matx_team_column_sortable' );

/* add new column */
function matx_team_column_head($columns) {
	unset($columns['date']);
    $columns['featured_image'] = __('Thumbnail', 'matx');
    $columns['team_role'] = __('Role', 'matx');
    $columns['date'] = __( 'Date', 'matx');
    
    return $columns;
}
 
/* show content into column */
function matx_populate_team_thumb($column_name, $post_ID) {

	switch ($column_name) {
		case 'featured_image':
   			( has_post_thumbnail( $post_ID )) ? the_post_thumbnail('matx-column-thumb') : ''; 
		break;

		case 'team_role' : 
	    	$prefix = '_matx_team_'; 
			$role  = get_post_meta( $post_ID, $prefix.'mamber_role', true );

			echo isset($role) ? esc_attr($role ) : '';
		break;
	}
}

/* make column sortable */

function matx_team_column_sortable( $columns ) {
    $columns['featured_image'] = 'Thumbnail';
    $columns['team_role'] = 'Role';

    return $columns;
}