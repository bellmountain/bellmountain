<?php
/**
 * Plugin Name: Matx Post Types
 * Plugin URI: http://themeforest.net/user/coderpixel
 * Description: Register all post type used in Matx - Material Design Agency Theme 
 * Version: 1.0.0
 * Author: Coderpixel
 * Author URI: http://themeforest.net/user/coderpixel
 */

 

define( 'MATXPOSTTYPES', __FILE__ ); 

define( 'MATXPOSTTYPE_PLUGIN_DIR', untrailingslashit( dirname( MATXPOSTTYPES ) ) );
 

/**
 * Register post type for coderpixel matx theme .
 *
 * @link http://codex.wordpress.org/Function_Reference/register_post_type
 */

add_action( 'init', 'matx_register_posttypes' );

function matx_register_posttypes() {

	/* Register matx team */

	$labels_team = array(
		'name'               => __( 'Team Members', 'matx' ),
		'singular_name'      => __( 'Team Member', 'matx' ),
		'menu_name'          => __( 'Team Members', 'matx' ),
		'name_admin_bar'     => __( 'Team Member', 'matx' ),
		'add_new'            => __( 'Add New', 'matx' ),
		'add_new_item'       => __( 'Add New Team Member', 'matx' ),
		'new_item'           => __( 'New Team Member', 'matx' ),
		'edit_item'          => __( 'Edit Team Member', 'matx' ),
		'view_item'          => __( 'View Team Member', 'matx' ),
		'all_items'          => __( 'All Members', 'matx' ),
		'search_items'       => __( 'Search Team Members', 'matx' ),
		'parent_item_colon'  => __( 'Parent Team Member:', 'matx' ),
		'not_found'          => __( 'No Team Member found.', 'matx' ),
		'not_found_in_trash' => __( 'No Team Member found in Trash.', 'matx' )
	);
	$args_team = array(
		'labels'             => $labels_team,
        'description'        => __( 'Description.', 'matx' ),
		'public'             => false,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'show_in_nav_menus'  => false,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'matx-team' ),
		'capability_type'    => 'post',
		'has_archive'        => false,
		'hierarchical'       => false,
		'menu_position'      => null,
		'menu_icon'		     => plugin_dir_url(__FILE__).'assets/icons/team.png',
		'supports'           => array( 'title', 'thumbnail' )
	);
	register_post_type( 'matx-team', $args_team );


	/* Register matx testimonial */

	$labels_testimonial = array(
		'name'               => __( 'Testimonials', 'matx' ),
		'singular_name'      => __( 'Testimonial', 'matx' ),
		'menu_name'          => __( 'Testimonials', 'matx' ),
		'name_admin_bar'     => __( 'Testimonial', 'matx' ),
		'add_new'            => __( 'Add New', 'matx' ),
		'add_new_item'       => __( 'Add New Testimonial', 'matx' ),
		'new_item'           => __( 'New Testimonial', 'matx' ),
		'edit_item'          => __( 'Edit Testimonial', 'matx' ),
		'view_item'          => __( 'View Testimonial', 'matx' ),
		'all_items'          => __( 'All Testimonials', 'matx' ),
		'search_items'       => __( 'Search Testimonials', 'matx' ),
		'parent_item_colon'  => __( 'Parent Testimonials:', 'matx' ),
		'not_found'          => __( 'No testimonials found.', 'matx' ),
		'not_found_in_trash' => __( 'No testimonials found in Trash.', 'matx' )
	);
	$args_testimonial = array(
		'labels'             => $labels_testimonial,
        'description'        => __( 'Description.', 'matx' ),
		'public'             => false,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'show_in_nav_menus'  => false,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'matx-testimonial' ),
		'capability_type'    => 'post',
		'has_archive'        => false,
		'hierarchical'       => false,
		'menu_position'      => null,
		'menu_icon'		     => plugin_dir_url(__FILE__).'assets/icons/testimonials.png',
		'supports'           => array( 'title', 'thumbnail' )
	);
	register_post_type( 'matx-testimonial', $args_testimonial );

	/* Register matx specialty */

	$labels_specialty = array(
		'name'               => __( 'Specialties', 'matx' ),
		'singular_name'      => __( 'Specialty', 'matx' ),
		'menu_name'          => __( 'Specialties', 'matx' ),
		'name_admin_bar'     => __( 'Specialty', 'matx' ),
		'add_new'            => __( 'Add New', 'matx' ),
		'add_new_item'       => __( 'Add New Specialty', 'matx' ),
		'new_item'           => __( 'New Specialty', 'matx' ),
		'edit_item'          => __( 'Edit Specialty', 'matx' ),
		'view_item'          => __( 'View Specialty', 'matx' ),
		'all_items'          => __( 'All Specialties', 'matx' ),
		'search_items'       => __( 'Search Specialties', 'matx' ),
		'parent_item_colon'  => __( 'Parent Specialties:', 'matx' ),
		'not_found'          => __( 'No specialties found.', 'matx' ),
		'not_found_in_trash' => __( 'No specialties found in Trash.', 'matx' )
	);
	$args_specialty = array(
		'labels'             => $labels_specialty,
        'description'        => __( 'Description.', 'matx' ),
		'public'             => false,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'show_in_nav_menus'  => false,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'matx-specialty' ),
		'capability_type'    => 'post',
		'has_archive'        => false,
		'hierarchical'       => false,
		'menu_position'      => null,
		'menu_icon'		     => plugin_dir_url(__FILE__).'assets/icons/specialty.png',
		'supports'           => array( 'title', 'editor', 'thumbnail' )
	);

	register_post_type( 'matx-specialty', $args_specialty );


	/* Register matx service */

	$labels_service = array(
		'name'               => __( 'Services', 'matx' ),
		'singular_name'      => __( 'Service', 'matx' ),
		'menu_name'          => __( 'Services', 'matx' ),
		'name_admin_bar'     => __( 'Service', 'matx' ),
		'add_new'            => __( 'Add New', 'matx' ),
		'add_new_item'       => __( 'Add New Service', 'matx' ),
		'new_item'           => __( 'New Service', 'matx' ),
		'edit_item'          => __( 'Edit Service', 'matx' ),
		'view_item'          => __( 'View Service', 'matx' ),
		'all_items'          => __( 'All Services', 'matx' ),
		'search_items'       => __( 'Search Services', 'matx' ),
		'parent_item_colon'  => __( 'Parent Services:', 'matx' ),
		'not_found'          => __( 'No services found.', 'matx' ),
		'not_found_in_trash' => __( 'No services found in Trash.', 'matx' )
	);
	$args_service = array(
		'labels'             => $labels_service,
        'description'        => __( 'Description.', 'matx' ),
		'public'             => false,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'show_in_nav_menus'  => false,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'matx-service' ),
		'capability_type'    => 'post',
		'has_archive'        => false,
		'hierarchical'       => false,
		'menu_position'      => null,
		'menu_icon'		     => plugin_dir_url(__FILE__).'assets/icons/service.png',
		'supports'           => array( 'title', 'thumbnail' )
	);


	register_post_type( 'matx-service', $args_service );


	/* Register matx portfolio */

	$labels_portfolio = array(
		'name'               => __( 'Portfolios', 'matx' ),
		'singular_name'      => __( 'Portfolio', 'matx' ),
		'menu_name'          => __( 'Portfolios', 'matx' ),
		'name_admin_bar'     => __( 'Portfolio', 'matx' ),
		'add_new'            => __( 'Add New', 'matx' ),
		'add_new_item'       => __( 'Add New Portfolio', 'matx' ),
		'new_item'           => __( 'New Portfolio', 'matx' ),
		'edit_item'          => __( 'Edit Portfolio', 'matx' ),
		'view_item'          => __( 'View Portfolio', 'matx' ),
		'all_items'          => __( 'All Portfolios', 'matx' ),
		'search_items'       => __( 'Search Portfolios', 'matx' ),
		'parent_item_colon'  => __( 'Parent Portfolios:', 'matx' ),
		'not_found'          => __( 'No portfolios found.', 'matx' ),
		'not_found_in_trash' => __( 'No portfolios found in Trash.', 'matx' )
	);
	$args_portfolio = array(
		'labels'             => $labels_portfolio,
        'description'        => __( 'Description.', 'matx' ),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'matx-portfolio' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'menu_icon'		     => plugin_dir_url(__FILE__).'assets/icons/portfolio.png',
		'supports'           => array( 'title', 'thumbnail' )
	);

	register_post_type( 'matx-portfolio', $args_portfolio );

}


/**
 * Register matx custom taxonomy
 */

add_action( 'init', 'matx_register_custom_taxonomy', 0 );

function matx_register_custom_taxonomy() {

	$p_cat_labels = array(
		'name'              => __( 'Categories', 'matx' ),
		'singular_name'     => __( 'Category', 'matx' ),
		'search_items'      => __( 'Search Categories', 'matx' ),
		'all_items'         => __( 'All Categories', 'matx' ),
		'parent_item'       => __( 'Parent Category', 'matx' ),
		'parent_item_colon' => __( 'Parent Category:', 'matx' ),
		'edit_item'         => __( 'Edit Category', 'matx' ),
		'update_item'       => __( 'Update Category', 'matx' ),
		'add_new_item'      => __( 'Add New Category', 'matx' ),
		'new_item_name'     => __( 'New Category Name', 'matx' ),
		'menu_name'         => __( 'Categories', 'matx' ),
	);

	$p_cat_args = array(
		'hierarchical'      => true,
		'labels'            => $p_cat_labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'portfolio-category' ),
	);

	register_taxonomy( 'portfolio-category', array( 'matx-portfolio' ), $p_cat_args ); 
}



/* Disable Team and Resume's Single page URL and Redirect Home*/

add_action( 'template_redirect', 'matx_redirect_post_without_single_page' );

function matx_redirect_post_without_single_page() {

	$queried_post_type = get_query_var('post_type');

	if ( ( is_single() && 'matx-team' ==  $queried_post_type ) ||
		( is_single() && 'matx-testimonial' ==  $queried_post_type ) ||
		( is_single() && 'matx-specialty' ==  $queried_post_type ) ||
		( is_single() && 'matx-service' ==  $queried_post_type ) ||
		( is_single() && 'personx_team' ==  $queried_post_type ) ) {
			wp_redirect( home_url(), 301 );
		exit;
	}

}


/**
 * add custom column for post type
 */

require_once MATXPOSTTYPE_PLUGIN_DIR . '/custom-columns/columns-post.php';
require_once MATXPOSTTYPE_PLUGIN_DIR . '/custom-columns/columns-team.php';
require_once MATXPOSTTYPE_PLUGIN_DIR . '/custom-columns/columns-service.php';
require_once MATXPOSTTYPE_PLUGIN_DIR . '/custom-columns/columns-portfolio.php';
require_once MATXPOSTTYPE_PLUGIN_DIR . '/custom-columns/columns-testimonial.php';
require_once MATXPOSTTYPE_PLUGIN_DIR . '/custom-columns/columns-specialties.php';






