<?php
/**
 * Plugin Name: Matx Shortcodes
 * Plugin URI: http://themeforest.net/user/coderpixel
 * Description: Shortcode for Matx - Material Design Agency wordpress theme. Shortcode are using into visual composer.
 * Version: 1.0
 * Author: Coderpixel
 * Author URI: http://coderpixel.com
 */


/**
* Theme section title
*
* @shortcode [matx-section-title]
*/

add_shortcode( 'matx-section-title', 'matx_section_title_shortcode');

function matx_section_title_shortcode($atts) {

	extract( shortcode_atts( array(
		'section_title_content'		=> '',
		'matx_sec_title_alignment' 	=> '',
		'matx_sec_title_color' 		=> '',
		'section_subtitle_content' 	=> '',
		'matx_sec_title_tag' 		=> '',
		'matx_sec_subtitle_color' 	=> '',
		'matx_sec_title_mb' 		=> '',
	),  $atts));

	$matx_sec_title = '';


	/* get title alignment from visual composer */
	switch ($matx_sec_title_alignment) {
		case 'left':
			$align_class = 'text-left';
		break;
			
		case 'right':
			$align_class = 'text-right';
		break;
		
		default:
			$align_class = 'text-center';
		break;
	}


	// open base title style attributes 
	$wrap_style = $base_style = $sub_style = 'style="';

	// set margin-bottom
	if( ! empty( $matx_sec_title_mb ) ) { $wrap_style .= 'margin-bottom: '.esc_attr( $matx_sec_title_mb ).'!important;'; } else { $wrap_style .= ''; }

	// set title color
	if( $matx_sec_title_color ) { $base_style.= 'color:'.esc_attr( $matx_sec_title_color ).';'; } else { $base_style.= ''; }

	// set subtitle color
	if( $matx_sec_subtitle_color ) { $sub_style.= 'color:'.esc_attr( $matx_sec_subtitle_color ).';'; } else { $sub_style.= ''; }

	// close title and subtitle style attributes 
	$wrap_style		.= '"';
	$base_style		.= '"';
	$sub_style		.= '"';


	// set title HTML tag
	$tt = ! empty( $matx_sec_title_tag ) ? $matx_sec_title_tag : 'h3';

	$matx_sec_title.= '<div class="'.esc_attr( $align_class ).' section-heading" '.$wrap_style.'>';

	$matx_sec_title .='<'.esc_html($tt).'  class="section-title" '.$base_style.'>'.esc_html( $section_title_content ).'</'.esc_html($tt).'>';

	if( ! empty( $section_subtitle_content ) ){
		$matx_sec_title.= '<h3 class="section-subtitle" '.$sub_style.'>'.esc_html($section_subtitle_content).'</h3>';
	}

	$matx_sec_title.= '</div>';

	return $matx_sec_title;
} 


/**
* Icon module.
*
* @shortcode [matx-icon-module]
*/
add_shortcode( 'matx-icon-module','matx_bodred_icon_module' );

function matx_bodred_icon_module($atts){

	extract( shortcode_atts(array(
		'css'					=> '',
		'icon_module_title'		=> '',
		'icon_module_des'		=> '',
		'ib_alignment'			=> '',
		'icon_module_iconclass'	=> '',
		'ib_title_tag'			=> '',
		'ib_style'				=> '',
		'ib_colorschem'			=> '',
		'animation'				=> '',
		'duration'				=> '',
		'delay'					=> '',
	), $atts ));

	$wrapper_class = array('clearfix', 'single-imodule');

	$wrapper_class[] = ($ib_style) ? $ib_style : 'style_one';

	// box alignment
	switch ($ib_alignment) {

		case 'center':
			$alignment_class = 'imodule-centerd';			
		break;

		case 'right':
			$alignment_class = 'imodule-rightaligned';		
		break;

		default:
			$alignment_class = 'imodule-leftaligned';
		break;
	}

	// box style
	switch ( $ib_style ) {

		case 'style_two':
			$wrapper_class[] = 'imodule-elements-block';
		break;

		case 'style_three':
			$wrapper_class[] = 'csch-gray-white hov-white-red imodule-round';
		break;

		case 'style_four':
			$wrapper_class[] = 'imodule-centerd rbodard-imodule';
			$alignment_class = '';
		break;

		case 'style_five':
			$wrapper_class[] = 'imodule-centerd imodule-icon-xxl';
		break;

		default :
			$wrapper_class[] = 'imodule-basic';
		break;
	}

	$wrapper_class[] = $alignment_class;

	// box color scheme
	$wrapper_class[] = ( $ib_colorschem == 'light' ) ? 'clscheme-light' : 'clscheme-dark';

	// box animation
	$animation = ($animation) ? $animation : false;
	if($animation != false ) {
		$wrapper_class[]	= 'wow '.$animation;
		$duration 			= $duration ? 'data-wow-duration="'.esc_attr($duration).'"' : 'data-wow-duration="1s"';
		$delay 				= $delay ? 'data-wow-delay="'.esc_attr($delay).'"' : '';
	} else {
		$duration = $delay = '';
	}

	// custom style
	$wrapper_class[] = ( class_exists('Vc_Manager')) ? vc_shortcode_custom_css_class($css) : '';

	$wrapper_class = array_filter($wrapper_class);

	$tt = ( empty($ib_title_tag )) ? 'h5' : $ib_title_tag;

	$html = '';

	if( ( $icon_module_title || $icon_module_des || $icon_module_iconclass ) ) :

		ob_start(); ?>

		<div class="<?php echo esc_attr(implode(' ', $wrapper_class)); ?>" <?php echo $duration.' '.$delay; ?>>
			<div class="icon-box">
				<i class="<?php echo esc_attr( $icon_module_iconclass ); ?>"></i>
			</div>
			<div class="ic-module-content">
				<?php echo '<'.esc_attr($tt).' class="imodule-title">'.esc_html( $icon_module_title ).'</'.esc_attr($tt).'>'; ?>
				<p><?php echo esc_html( $icon_module_des ); ?></p>
			</div>
		</div>

		<?php $result = ob_get_contents(); $html .= $result; ob_get_clean(); 

	endif;

	return $html;
}


 

/*
* Theme primary button.
*
* @shortcode [matx-btn]
*/
add_shortcode('matx-btn', 'matx_ui_button');

function matx_ui_button($atts) {

	extract(shortcode_atts(array(
		'text'				=> '',
		'link'				=> '',
		'color'				=> '',
		'alignment'			=> '',
		'button_fullwidth'	=> '',
		'attributes'		=> '',
		'css'				=> '',
		'animation'			=> '',
		'duration'			=> '',
		'delay'				=> '',
		'el_class'			=> '',
	), $atts ));


	$wrapper_class = array('matx-btn-wrap');

	$btn_classes = array('matx-primary-btn mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect btn-default');


	$btn_display = ( $alignment == ( 'left' || 'right' || 'center' ) ) ? 'block' : 'inline';

	if( $btn_display == 'block' ) {
			
		$wrapper_class[] = 'matx-btn-block';

		switch ($alignment) {

			case 'left':
				$wrapper_class[] = 'matx-btn-align-left';
			break;
			
			case 'right':
				$wrapper_class[] = 'matx-btn-align-right';
			break;
		
			default:
				$wrapper_class[] = 'matx-btn-align-center';
			break;
		}

		if( $button_fullwidth == true ) {
			$wrapper_class[] = 'matx-btn-full-width';
		}

	} else {
		
		$wrapper_class[] = 'matx-btn-inline';
	}


	switch ($color) {

		case 'black':
			$btn_classes[] = 'matx-btn-black';
		break;

		case 'cyan':
			$btn_classes[] = 'matx-btn-cyan';
		break;

		case 'indigo':
			$btn_classes[] = 'matx-btn-indigo';
		break;

		case 'orange':
			$btn_classes[] = 'matx-btn-orange';
		break;

		case 'blue':
			$btn_classes[] = 'matx-btn-blue';
		break;

		case 'pink':
			$btn_classes[] = 'matx-btn-pink';
		break;

		case 'green':
			$btn_classes[] = 'matx-btn-green';
		break;

		case 'purple':
			$btn_classes[] = 'matx-btn-purple';
		break;

		case 'deeppurple':
			$btn_classes[] = 'matx-btn-deep-purple';
		break;

		default:
			$btn_classes[] = 'matx-btn-brand';
		break;
	}

	// box animation
	$animation = ($animation) ? $animation : false;
	if($animation != false ) {
		$wrapper_class[]	= 'wow '.$animation;
		$duration 			= $duration ? 'data-wow-duration="'.esc_attr($duration).'"' : 'data-wow-duration="1s"';
		$delay 				= $delay ? 'data-wow-delay="'.esc_attr($delay).'"' : '';
	} else {
		$duration = $delay = '';
	}


	$data = ($attributes) ?  $attributes : '';


	if($el_class) {
		$btn_classes[]  = $el_class;
	}
	
	$btn_classes[] = class_exists('Vc_Manager') ? apply_filters(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class($css, ' '), $atts ) : '';


	$link = ( '||' === $link ) ? '' : $link;

	$link = vc_build_link( $link );

	$btn_url 	= ($link['url']) ? $link['url'] : '';
	$btn_title 	= ($link['title']) ? 'title="'.esc_attr($link['title'] ).'"' : '';
	$btn_target = ($link['target']) ? 'target="_blank"' : '';
	$btn_rel 	= ($link['rel']) ? 'rel="nofollow"' : '';


	$html = '';

	if($text) : ob_start();  ?>

	<div class="<?php echo esc_attr( implode(' ', $wrapper_class) ); ?>" <?php echo $duration.' '.$delay; ?>>
		<a href="<?php echo esc_url($btn_url); ?>" <?php echo $btn_title.' '.$btn_target.' '.$btn_rel; ?> class="<?php echo esc_attr( implode(' ', $btn_classes) ); ?>" <?php echo ' '.esc_attr($data); ?>><?php echo esc_html($text); ?></a>
	</div>

	<?php 

	$result = ob_get_contents(); $html .= $result; ob_get_clean(); endif;

	return $html;

}


/* Skill progress bar. */
add_shortcode('matx-skill-progressbar', 'matx_skill_progress_bar');

function matx_skill_progress_bar($atts){
	
	extract( shortcode_atts( array(
		'skill_name'	=> '',
		'skill_count'	=> '',
	), $atts ));

	$html = '';

	if( $skill_count && $skill_name ) : ob_start(); ?>

	<div class="progress-bar-inner" data-action="progress-bar">
		<span class="progress-bar-label"><?php echo esc_html($skill_name); ?></span>
		<div class="progress-bar">
			<div class="progress-bar-L1" data-width="<?php echo esc_attr($skill_count); ?>">
				<div class="progress-conunt"><span><?php echo esc_html($skill_count); ?></span></div>
			</div>
		</div>
	</div>

	<?php $result = ob_get_contents(); $html .= $result; ob_get_clean(); endif;

	return $html;
}



/* Pricing table. */
add_shortcode('matx-pricingtable', 'matx_display_pricing_table');

function matx_display_pricing_table($atts){

	extract(shortcode_atts( array(
		'matx_pt_price'			=> '',
		'matx_pt_currency'		=> '',
		'matx_pt_licence'		=> '',
		'matx_pt_content'		=> '',
		'matx_pt_btntext'		=> '',
		'matx_pt_recommended'	=> '',
		'link'					=> '',
		'animation'				=> '',
		'duration'				=> '',
		'delay'					=> '',
	), $atts ));

	$wrapper_class = array('primary-bg-color pricing-table jumbo-shadow mdl-shadow--2dp');

	$btn_classes = array('mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect btn-default');

	$btn_text = esc_html__('START THIS PLAN', 'matx');

	if($matx_pt_btntext) {
		$btn_text = esc_html($matx_pt_btntext);
	}

	if( $matx_pt_recommended == 'pt_rec_yes'){

		$wrapper_class[] = 'recommended-plan';
		$btn_classes[] = 'btn-highlight';

	} else {
		$btn_classes[] = 'btn-black';
	}

	// box animation
	$animation = ($animation) ? $animation : false;
	if($animation != false ) {
		$wrapper_class[]	= 'wow '.$animation;
		$duration 			= $duration ? 'data-wow-duration="'.esc_attr($duration).'"' : 'data-wow-duration="1s"';
		$delay 				= $delay ? 'data-wow-delay="'.esc_attr($delay).'"' : '';
	} else {
		$duration = $delay = '';
	}


	$link = ( '||' === $link ) ? '' : $link;

	$link = vc_build_link( $link );

	$btn_url 	= ($link['url']) ? $link['url'] : '#';
	$btn_title 	= ($link['title']) ? 'title="'.esc_attr($link['title'] ).'"' : '';
	$btn_target = ($link['target']) ? 'target="_blank"' : '';
	$btn_rel 	= ($link['rel']) ? 'rel="nofollow"' : '';

	$html = '';

	ob_start(); ?>

	<div class="<?php echo esc_attr(implode(' ', $wrapper_class)); ?>" <?php echo $duration.' '.$delay; ?>>
		<div class="text-left pct-header">
			<div class="plan-price">
				<?php if( $matx_pt_price ) : ?>
					<span class="currency"><?php echo ($matx_pt_currency) ? esc_html($matx_pt_currency): '$'; ?></span>
					<span class="price"><?php echo esc_html( $matx_pt_price ); ?></span>
				<?php endif; ?>
			</div>
			<?php echo ($matx_pt_licence) ? '<div class="licence-type">'.esc_html( $matx_pt_licence ).'</div>' : ''; ?>
		</div>
		
		<?php if( $matx_pt_content ) : ?>

		<div class="pct-body">
			<ul class="plan-feature">
				<?php 

					$list_text = str_replace('<br />', ',', $matx_pt_content );
					$list_text = explode(',',$list_text);

					foreach ($list_text as $list) {
						echo '<li>'.esc_html( $list ). '</li>';
					}
				?>
			</ul>
		</div>

		<?php endif; ?>

		<div class="pc-foot">
			<a class="<?php echo esc_attr(implode(' ', $btn_classes) ); ?>" href="<?php echo esc_url($btn_url); ?>" <?php echo $btn_title.' '.$btn_target.' '.$btn_rel; ?>><?php echo $btn_text; ?></a>
		</div>
	</div>

	<?php $result = ob_get_contents(); $html .= $result; ob_get_clean();

	return $html;
}



/* Team member */
add_shortcode('matx-team', 'matx_display_post_team');

function matx_display_post_team($atts) {

	extract( shortcode_atts( array(
		'id'	=> '',
		'style'	=> '',
	), $atts ) );

	$team_args = array(
		'post_type' 		=> 'matx-team',
		'post_status' 		=> 'publish',
		'posts_per_page' 	=> -1
	);

	if( $id ){
		
		$team_args['p'] = $id;
	}

	$team_query = new WP_Query( $team_args );
	$prefix = '_matx_team_';

	$html = '';

	$thumb_size = ( $style == '3' ) ? 'matx-team-3col' : 'matx-team-4col';

	if( $team_query->have_posts()) : while( $team_query->have_posts() ) : $team_query->the_post();

		$role  = get_post_meta( get_the_ID(), $prefix.'mamber_role', true );
		$team_social_group = get_post_meta( get_the_ID(), $prefix.'social_media', true );
		$team_skill_group = get_post_meta( get_the_ID(), $prefix.'skill_info', true );

		$html .= '<div class="col-sm-12">';

		$html .= '<div class="team-member">';

				$html .= '<div class="member-img">';

				if ( has_post_thumbnail() ) {

					$html .= get_the_post_thumbnail( get_the_id(), $thumb_size  );
				}

				$html .= '</div>';
				$html .= '<div class="text-center member-info">';

					$html .= '<h4 class="title-four member-name">'.esc_html( get_the_title() ).'</h4>';

					$html .= '<div class="member-role">'.esc_html( $role ).'</div>';
					$html .= '<div class="member-toggle">';

						$html .= '<div class="member-skills">';
							$html .= '<ul class="progress-bar-wrap">';
								foreach ( (array) $team_skill_group as $key => $sk_entry ) {

									$sk_title = $sk_count = '';

									isset($sk_entry[ $prefix.'skill_title']) ? $sk_title = $sk_entry[ $prefix.'skill_title' ] : ''; 
									isset($sk_entry[ $prefix.'skill_count']) ? $sk_count = $sk_entry[ $prefix.'skill_count' ] : '';

									$html .= '<li class="progress-bar-inner">';

										$html .= '<span class="progress-bar-label">'.esc_html($sk_title ).'</span>';
										$html .= '<div class="progress-bar">';
											$html .= '<div class="progress-bar-L1" style="width: '.esc_attr( $sk_count ).';">';
												$html .= '<div class="progress-conunt"><span>'.esc_html( $sk_count ).'</span></div>';
											$html .= '</div>';
										$html .= '</div>';
									$html .= '</li>';
								}
							$html .= '</ul>';
						$html .= '</div>';

						$html .= '<ul class="clearfix social member-social hover-round">';

							foreach ( (array) $team_social_group as $key => $sc_entry ) {

								$sc_title = $sc_url = $sc_icon = '';

								isset($sc_entry[ $prefix.'social_media_title']) ? $sc_title = $sc_entry[ $prefix.'social_media_title' ] : ''; 
								isset($sc_entry[ $prefix.'social_media_url']) ? $sc_url = $sc_entry[ $prefix.'social_media_url' ] : ''; 
								isset($sc_entry[ $prefix.'social_media_icon']) ? $sc_icon = $sc_entry[ $prefix.'social_media_icon' ] : ''; 

								$html .= '<li><a target="_blank" href="'.esc_url( $sc_url ).'" title="'.esc_attr( $sc_title ).'"><i class="'.esc_attr( $sc_icon ).'"></i></a></li>';
							}
						$html .= '</ul>';
					$html .= '</div>';
				$html .= '</div>';
			$html .= '</div>';
		$html .= '</div>';

	endwhile; endif; wp_reset_postdata();

	return $html;

}



/* Team member slider */
add_shortcode( 'matx-teams', 'matx_display_team_slider');

function matx_display_team_slider($atts){

	extract( shortcode_atts( array(
		'matx_team_member_ids'		=> '',
		'matx_team_style' 			=> '',
		'matx_team_column_grid'		=> '',
		'autoplay'					=> '',
	), $atts ));

	$settings = array();

	$wrapper_class = array('matx-team-carousel-wrap styled-paginantion colorsch-white');

	$team_ids = explode( ",", $matx_team_member_ids );

	$team_ids = array_filter($team_ids);
	

	/* switch team style */

	switch ( $matx_team_style ) {

		case 'style_two':
			$wrapper_class[] = 'team-style-2';
		break;

		case 'style_three':
			$wrapper_class[] = 'team-style-3';
		break;

		default:
			$wrapper_class[] = 'team-style-1';
		break;
	}

	// Get the last index like : 1, 2 , 3;
	$team_columns = ( $matx_team_column_grid ) ? substr( $matx_team_column_grid, -1 ) : 3;

	if($team_columns == '4') {

		$wrapper_class[] = 'matx-team-columns-4';

	} else {

		$wrapper_class[] = 'matx-team-columns-3';

	}


	$style = $team_columns;

	$settings['item'] = $team_columns;


	$settings['autoplay'] = ($autoplay == 'off') ? false : true;

	$html = '';

	ob_start(); ?>


	<div class="<?php echo esc_attr( implode(' ', $wrapper_class) ); ?>" data-settings="<?php echo esc_attr( json_encode($settings) ); ?>" data-action="teamSlider">

		<?php 
			if( $team_ids ) {
				foreach ($team_ids as $team_id) {
					echo do_shortcode('[matx-team id="'.$team_id.'" style="'.$style.'"]' );	
				}
			} else {
				echo do_shortcode('[matx-team style="'.$style.'"]' );	
			}
		 ?>
	</div>

	<?php

	$result = ob_get_contents(); $html .= $result; ob_get_clean();

	return $html;
}



/* Specialty accordion. */
add_shortcode( 'matx-specialty', 'matx_speciality_accordion');

function matx_speciality_accordion($atts) {	
	
	extract( shortcode_atts( array(
		'matx_sp_style'		=> '',
		'matx_sppost_ids'	=> ''
	), $atts ));

	$spcialty_posts = array_filter( explode(',', $matx_sppost_ids) );

	$args = array(
		'post_type'   		=> 'matx-specialty',
		'post_status' 		=> 'publish',
		'posts_per_page'	=> -1
	);

	if( count($spcialty_posts) > 0 ) {
		$args['post__in'] = $spcialty_posts;
	}

	$specialty_query = new WP_Query( $args );

	$prefix = '_matx_specialty_';						
	$getsp_posts = wp_count_posts( 'matx-specialty' );

	$html = '';

	if( $specialty_query->have_posts() ) {

		if( $matx_sp_style == 'accordion') {
			
			$html .= '<div class="row why-choose-us-content-start" data-action="accordionWithImage">';
				$html .= '<div class="col-sm-12 col-md-6 col-lg-offset-1 col-lg-5">';
					$html .= '<ul class="wcu-collapse">';

						$i = 0;

						while( $specialty_query->have_posts() ) : $specialty_query->the_post();

							$i++;

							if( has_post_thumbnail( get_the_ID() ) ) {

								$thumb_src = get_the_post_thumbnail_url( get_the_id(), 'specialty-accordion' );

								$thumb_id = get_post_thumbnail_id( get_the_id() );

								$thumb_url = get_the_post_thumbnail_url( get_the_id(), 'specialty-accordion' );

								$sp_alt = get_post_meta($thumb_id, '_wp_attachment_image_alt', true);

								if( ! $sp_alt ) {
									$sp_alt = get_the_title();
								}

							} else {
								
								$thumb_src = '';

								$sp_alt = '';
							}

							if( $i == 1 ) {
								$html .= '<li class="single-acc-item collapse-open" data-image-alt="'.esc_attr($sp_alt ).'" data-image-src="'.esc_attr($thumb_src ).'">';
							} else {

								$html .= '<li class="single-acc-item" data-image-alt="'.esc_attr($sp_alt).'" data-image-src="'.esc_attr($thumb_src ).'">';
							}
								$html .= '<div class="collapse-label">';
									$html .= '<div class="cllabelmain">'.esc_html( get_the_title() ).'</div>';
									$html .= '<div class="icwrap"><i class="zmdi zmdi-plus"></i></div>';
								$html .= '</div>';
								$html .= '<div class="collapse-content">'.esc_html( get_the_content() ).'</div>';
							$html .= '</li>';
						endwhile;
					$html .= '</ul>';
				$html .= '</div>';
				$html .= '<div class="col-sm-12 col-md-6 col-lg-5">';
					$html .= '<div class="wcu-thumb-wrap acc-thumb-area">';

					$i = 0;
					while( $specialty_query->have_posts() ) : $specialty_query->the_post();

						$i++ ;

						if( $i == 1 && has_post_thumbnail( get_the_id() ) ) {

							$thumb_id = get_post_thumbnail_id( get_the_id() );

							$thumb_url = get_the_post_thumbnail_url( get_the_id(), 'specialty-accordion' );

							$sp_alt = get_post_meta($thumb_id, '_wp_attachment_image_alt', true);

							if( $sp_alt ){

								$html .= '<img src="'.esc_url( $thumb_url ).'" alt="'.esc_attr( $sp_alt ).'">';

							} else {
								
								$html .= '<img src="'.esc_url( $thumb_url ).'" alt="'.esc_html( get_the_title() ).'">';
							}
						}

					endwhile;

					$html .= '</div>';
				$html .= '</div>';
			$html .= '</div>';

		} elseif ( $matx_sp_style == 'carousal' ) {
 
			$html .= '<div class="wcu-slider-wrap">';
				$html .= '<div class="ov-hidden">';
					$html .= '<div class="row">';

						/* slider will be initiated if post count will up to 4 */
						if( count( $spcialty_posts ) > 4 ) {
							$html .= '<div class="clearfix slider-items" data-action="whyChoseUsSlider">';

							$sp_item_wrap = '<div class="col-md-3">';

						} else {

							$html .= '<div class="clearfix slider-items">';

							switch ( count( $spcialty_posts ) ) {
								case 1:
									$sp_item_wrap = '<div class="col-sm-12">';
									break;
								case 2:
									$sp_item_wrap = '<div class="col-xs-6 col-sm-6">';
									break;
								case 3:
									$sp_item_wrap = '<div class="col-xs-12 col-sm-4">';
									break;
								default:
									$sp_item_wrap = '<div class="col-xs-12 col-sm-3">';
								break;
							}
						}

						while( $specialty_query->have_posts() ) : $specialty_query->the_post();

							$sp_iconclass = get_post_meta( get_the_id(), $prefix.'icon_class', true ); 	

							$html .= $sp_item_wrap;

								$html .= '<div class="text-center cp-cards why-chose-us-cards specialty-slider-card">';
									if( $sp_iconclass ) {
										$html .= '<div class="card-head"><i class="'.esc_attr( $sp_iconclass ).'"></i></div>';
									}
									$html .= '<div class="card-body">';
										$html .= '<h3 class="card-title">'.esc_html( get_the_title() ).'</h3>';
										$html .= '<div>'.esc_html( get_the_content() ).'</div>';
									$html .= '</div>';

								$html .= '</div>';

							$html .= '</div>';

						endwhile;

						$html .= '</div>';
					$html .= '</div>';
				$html .= '</div>';

				if( count( $spcialty_posts ) > 4 ){
					$html .= '<div class="clearfix slider-cntrl specialty-slider-ctrl">';
						$html .= '<a href="#" class="mdl-button mdl-js-button mdl-js-ripple-effect left-arrow wow fadeInLeft" data-wow-duration="1s"><i class="zmdi zmdi-chevron-left"></i></a>';
						$html .= '<a href="#" class="mdl-button mdl-js-button mdl-js-ripple-effect right-arrow wow fadeInRight" data-wow-duration="1s"><i class="zmdi zmdi-chevron-right"></i></a>';
					$html .= '</div>';
				} // endif; $specialty_slider_numpost
			$html .= '</div>'; 

		}
	}

	wp_reset_postdata();

	return $html;
}



/* Specialty Slider. */
add_shortcode('matx-specialty-slider', 'matx_speciality_slider');

function matx_speciality_slider($atts){
	extract(shortcode_atts(array(
		'specialty_slider_numpost'	=> ''
	), $atts ));

	$args = array(
		'post_type'   		=> 'matx-specialty',
		'post_status' 		=> 'publish',	
		'posts_per_page'    => ( !empty( $specialty_slider_numpost ) ) ? $specialty_slider_numpost : -1,	
	);
	$specialty_slider = new WP_Query($args);

	$prefix = '_matx_specialty_';
	$html = ''; 


	if( $specialty_slider->have_posts()) : 

	$getsp_posts = wp_count_posts( 'matx-specialty' );
 
	$html .= '<div class="wcu-slider-wrap">';
		$html .= '<div class="ov-hidden">';
			$html .= '<div class="row">';

				if( ( $specialty_slider_numpost > 4 ) && ( $getsp_posts->publish > 4 ) ) {
					$html .= '<div class="clearfix slider-items" data-action="whyChoseUsSlider">';

					while( $specialty_slider->have_posts() ) : $specialty_slider->the_post();

					$html .= '<div class="col-md-12">';

					$sp_iconclass = get_post_meta( get_the_id(), $prefix.'icon_class', true ); 
					
						$html .= '<div class="text-center cp-cards why-chose-us-cards specialty-slider-card">';
							if( $sp_iconclass ) {
								$html .= '<div class="card-head"><i class="'.esc_attr( $sp_iconclass ).'"></i></div>';
							}
							$html .= '<div class="card-body">';
								$html .= '<h3 class="card-title">'.esc_html( get_the_title() ).'</h3>';
								$html .= '<div>'.esc_html( get_the_content() ).'</div>';
							$html .= '</div>';
						$html .= '</div>';
					$html .= '</div>';

					endwhile;
				} else {
					$html .= '<div class="clearfix slider-items">';

					while( $specialty_slider->have_posts() ) : $specialty_slider->the_post();

					switch ( $getsp_posts->publish ) {
						case 1:
							$html .= '<div class="col-sm-12">';
							break;
						case 2:
							$html .= '<div class="col-xs-6 col-sm-6">';
							break;
						case 3:
							$html .= '<div class="col-xs-12 col-sm-4">';
							break;
						default:
							$html .= '<div class="col-xs-12 col-sm-3">';
						break;
					}

					$sp_iconclass = get_post_meta( get_the_id(), $prefix.'icon_class', true ); 
					
						$html .= '<div class="text-center cp-cards why-chose-us-cards specialty-slider-card">';
							if( $sp_iconclass ) {
								$html .= '<div class="card-head"><i class="'.esc_attr( $sp_iconclass ).'"></i></div>';
							}
							$html .= '<div class="card-body">';
								$html .= '<h3 class="card-title">'.esc_html( get_the_title() ).'</h3>';
								$html .= '<div>'.esc_html( get_the_content() ).'</div>';
							$html .= '</div>';
						$html .= '</div>';
					$html .= '</div>';

					endwhile;
				}

				$html .= '</div>';
			$html .= '</div>';
		$html .= '</div>';

		if( ( $specialty_slider_numpost > 4 ) && ( $getsp_posts->publish > 4 ) ){
			$html .= '<div class="clearfix slider-cntrl specialty-slider-ctrl">';
				$html .= '<a href="#" class="mdl-button mdl-js-button mdl-js-ripple-effect left-arrow wow fadeInLeft" data-wow-duration="1s"><i class="zmdi zmdi-chevron-left"></i></a>';
				$html .= '<a href="#" class="mdl-button mdl-js-button mdl-js-ripple-effect right-arrow wow fadeInRight" data-wow-duration="1s"><i class="zmdi zmdi-chevron-right"></i></a>';
			$html .= '</div>';
		} // endif; $specialty_slider_numpost
	$html .= '</div>'; 

	endif; wp_reset_postdata();

	return $html;
}



/* Testimonial */

add_shortcode('matx-testimonial', 'matx_post_testimonial');

function matx_post_testimonial($atts){
	
	extract( shortcode_atts( array(
		'id'	=> ''
	), $atts ) );

	$test_args = array(
		'post_type' 		=> 'matx-testimonial',
		'post_status' 		=> 'publish',
		'posts_per_page' 	=> -1
	);

	if( $id ){ $test_args['p'] =  $id; }

	$test_query = new WP_Query( $test_args );

	$html = '';

	if( $test_query->have_posts() ) : while( $test_query->have_posts() ) : $test_query->the_post();

		$prefix = '_matx_testimonial_';

		$recom_text = get_post_meta( get_the_id(), $prefix.'recom_text', true );
		$recom_name = get_post_meta( get_the_id(), $prefix.'recom_name', true );
		$recom_org = get_post_meta( get_the_id(), $prefix.'recom_org', true );

		if( $recom_text || $recom_name || $recom_org || has_post_thumbnail()) {

			$img_id 	= get_post_thumbnail_id( get_the_id() );
			$img_alt 	= get_post_meta($img_id, '_wp_attachment_image_alt', true);
			$img_src 	= wp_get_attachment_image_src( $img_id );

			$html .= '<div class="text-center single-testimonial">';

				if( $img_src ) {

					$html .= '<div class="recomenders-thumb">';

						if( $img_alt ) {
							$html .= '<img src="'.esc_url( $img_src[0] ).'" alt="'.esc_attr( $img_alt ).'">';
						} else {
							$html .= '<img src="'.esc_url( $img_src[0] ).'" alt="'.esc_attr( $recom_name ).'">';
						}

					$html .= '</div>';
				}

				$html .= '<div class="recomenders-info">';

					if( $recom_text ) {
						$html .= '<p>'.esc_html( $recom_text ).'</p>';
					}

					if( $recom_name ){

						if( $recom_org ) {

							$html .= '<div><span class="recomenders-name">'.esc_html( $recom_name ).',&nbsp;</span><span class="recomenders-role">'.esc_html($recom_org ).'</span></div>';
						} else {
							$html .= '<div><span class="recomenders-name">'.esc_html( $recom_name ).'</div>';
						}
					}
				$html .= '</div>';
			$html .= '</div>';
		}

	endwhile; endif; wp_reset_postdata();

	return $html;
}



/* Testimonial slider */
add_shortcode('matx-testimonials', 'matx_display_testimonial_slider' );

function matx_display_testimonial_slider($atts){
	extract( shortcode_atts( array(
		'matx_testimonial_ids'		=> '',
		'matx_testimonail_thumb'	=> '',
		'matx_testimonail_nav'		=> '',
		'matx_testimonail_color'	=> '',
		'matx_testimonail_page'		=> '',
		'animation'					=> '',
		'duration'					=> '',
		'delay'						=> '',
	), $atts ) );

	$navigation = ( $matx_testimonail_nav 	== 'navigation_disable' ) ? 'disable' : 'enable';
	$pagination = ( $matx_testimonail_page 	== 'pagination_disable' ) ? 'disable' : 'enable';

	$html = '';

	$test_ids = explode(',', $matx_testimonial_ids);

	$test_ids = array_filter($test_ids);

	$wrapper_class = array('testimonial-slider styled-paginantion content-italic');


	$wrapper_class[] = ( $navigation == 'enable' ) ? 'js-nav-arrow-enabled testimonial-with-nav' : 'testimonial-without-nav';
	
	$wrapper_class[] = ( $pagination == 'enable' ) ? 'testimonial-with-pagination ' : 'testimonial-without-pagination';

	$wrapper_class[] = ( $matx_testimonail_thumb == 'image_disable' ) ? 'no-thumb-img ' : 'has-thumb-img';

	$wrapper_class[] = ( $matx_testimonail_color == 'test_color_black' ) ? 'colorsch-white' : 'colorsch-black';

	// box animation
	$animation = ($animation) ? $animation : false;
	if($animation != false ) {
		$wrapper_class[]	= 'wow '.$animation;
		$duration 			= $duration ? 'data-wow-duration="'.esc_attr($duration).'"' : 'data-wow-duration="1s"';
		$delay 				= $delay ? 'data-wow-delay="'.esc_attr($delay).'"' : '';
	} else {
		$duration = $delay = '';
	}

	ob_start(); ?>
	
	<div class="matx-testimonial-slider-wrap">
		
		<div class="<?php echo esc_attr( implode(' ', $wrapper_class) ); ?>" data-action="testimonialSlider" data-pagination="<?php echo esc_attr( $pagination ); ?>" <?php echo $duration.' '.$delay; ?>>

			<?php if( $test_ids ) :
					foreach ($test_ids as $id ) : 
						echo do_shortcode('[matx-testimonial id="'.$id.'" ]');
					endforeach;

				else :
					echo do_shortcode('[matx-testimonial]');
				endif;
			?>
		</div>

		<?php if( $navigation == 'enable' ) : ?>
			<div class="ts-slider-navwrap">
				<a href="#" class="mdl-button mdl-js-button mdl-js-ripple-effect ch-gray-white left-arrow icon-arrow round-arrow ts-slider-nav">
					<i class="zmdi zmdi-chevron-left"></i>
				</a>
				<a href="#" class="mdl-button mdl-js-button mdl-js-ripple-effect ch-gray-white right-arrow icon-arrow round-arrow ts-slider-nav">
					<i class="zmdi zmdi-chevron-right"></i>
				</a>
			</div>
		<?php endif; ?>
	</div>

	<?php 

	$result = ob_get_contents(); $html .= $result; ob_get_clean();

	return $html;
}



/* service tab menu  */
add_shortcode('matx-service-tabmenu', 'matx_display_service_tabmenu' );

function matx_display_service_tabmenu($atts) {

	extract( shortcode_atts( array(
		'id'	=> '',
		'count'	=> ''
	), $atts) );

	$service_args = array(
		'post_type' 		=> 'matx-service',
		'post_status' 		=> 'publish',
		'posts_per_page' 	=> 1,
		'p'					=> $id
	);

	$service_query = new WP_Query( $service_args );

	$html = '';

	$prefix = '_matx_service_';

	if( $service_query->have_posts() ) : while( $service_query->have_posts() ) : $service_query->the_post(); // $i++; 

		$service_tab_icon = get_post_meta( get_the_id(), $prefix.'tab_icon',true );

		$tab_icon = $service_tab_icon ? $service_tab_icon : 'zmdi zmdi-equalizer';

		$active_class = ($count == 1) ? 'is-active' : '';

		$html .= '<a href="#matx-service-tab'.$count.'" class="mdl-tabs__tab '.$active_class.'"><i class="'.esc_attr( $tab_icon ).'"></i></a>';

	endwhile; endif; wp_reset_postdata();

	return $html;
}



/* Service tab content  */
add_shortcode('matx-service-content', 'mat_service_content' );

function mat_service_content($atts){

	extract( shortcode_atts( array(
		'id'		=> '',
		'count'		=> ''
	),  $atts ) );

	$service_args = array(
		'post_type' 		=> 'matx-service',
		'post_status' 		=> 'publish',
		'posts_per_page' 	=> 1,
		'p'					=> $id
	);

	$service_query = new WP_Query( $service_args );

	$prefix = '_matx_service_';


	if( $service_query->have_posts() ) :  while( $service_query->have_posts() ) : $service_query->the_post();

	$service_title = get_post_meta( get_the_id(), $prefix.'title',true );
	$service_content = get_post_meta( get_the_id(), $prefix.'content',true );
	$service_exp = get_post_meta( get_the_id(), $prefix.'year_ex',true );
	$statistics_group = get_post_meta( get_the_id(), $prefix.'statistic',true );


	$html = '';

	if( $count == 1 ){

		$html .= '<div class="mdl-tabs__panel animated animateSlow fadeIn matx-service-tabpanel is-active" id="matx-service-tab'.$count.'">';

	} else {

		$html .= '<div class="mdl-tabs__panel animated animateSlow fadeIn matx-service-tabpanel init-hide" id="matx-service-tab'.$count.'">';
	}
		$html .= '<div class="row tab-title-wrap">';

			if( has_post_thumbnail(get_the_id()) ) {

				$html .= '<div class="col-sm-6">';
			} else {
				
				$html .= '<div class="col-sm-12">';
			}
				$html .= '<h3 class="card-title tab-title">'.$service_title.'</h3>';
				$html .= '<div class="service-content-text">'.wp_kses_post( $service_content ).'</div>';

			$html .= '</div>';

			if( has_post_thumbnail( get_the_id() )){

				$html .= '<div class="col-sm-6">';
					$html .= '<div class="tab-content text-center">';

						$html .= wp_get_attachment_image( get_post_thumbnail_id( ), 'service-thumb', false, array( 'class' => 'bordred-img' ) ); 

					$html .= '</div>';
				$html .= '</div>';
			}

		$html .= '</div>';

			if($service_exp){
				$html .= '<div class="text-center tab-histry">';
					$html .= wp_kses_post($service_exp );
				$html .= '</div>';
			}

		$html .= '<div class="row satistic-wrap">';

			/* Display project counter */
			$static_count = count($statistics_group);

			$st_count = 0;

			foreach ( (array) $statistics_group as $key => $st_value ) {

				$st_count++;

				$st_title = $st_number =  $st_icon = '';

				isset($st_value[ $prefix.'st_title']) 	? $st_title 	= $st_value[ $prefix.'st_title' ] 	: ''; // counter title
				isset($st_value[ $prefix.'st_number']) 	? $st_number 	= $st_value[ $prefix.'st_number' ] 	: ''; // counter count
				isset($st_value[ $prefix.'st_icon']) 	? $st_icon 		= $st_value[ $prefix.'st_icon' ] 	: ''; // counter icon

				if( $st_title || $st_number || $st_icon) {

						/* for single project counter */
						if ( $static_count == 1 ) {

							$col_class_name = 'col-sm-12 text-center';

						} elseif ( $static_count == 2 ) { /* for 2 project counter */

							$col_class_name = 'col-xxs-12 col-xs-6 col-sm-6 text-center';

						} elseif ( $static_count == 3 ) { /* for 3 project counter */

							if($st_count == 1 ){

								$col_class_name = 'col-xxs-4 col-xs-4';

							} elseif ($st_count == 2 ) {

								$col_class_name = 'col-xxs-4 col-xs-4 text-center';

							} elseif ($st_count == 3 ) {

								$col_class_name = 'col-xxs-4 col-xs-4 text-right';
							}

						} else { /* for 4 and extra project counter */

							$col_class_name = 'col-xxs-6 col-xs-3 text-center';
						}

						$html .= '<div class="'.$col_class_name.'">';

						$html .= '<div class="satistic">';

							if( $st_icon ) {

								$html .= '<div class="top"><i class="'.esc_attr( $st_icon ).'"></i><span class="countNumb" data-from="1" data-to="'.esc_attr( $st_number ).'">'.esc_html( $st_number ).'</span></div>';
							} else {

								$html .= '<div class="top"><i class="zmdi zmdi-equalizer"></i><span class="countNumb" data-from="1" data-to="'.esc_attr( $st_number ).'">'.esc_html( $st_number ).'</span></div>';
							}

							$html .= '<div class="bottom">'.esc_html( $st_title ).'</div>';

						$html .= '</div>';
					$html .= '</div>';
				}
			}
		$html .= '</div>';
	$html .= '</div>';

	endwhile; endif; wp_reset_postdata();


	return $html;
}



/* service tab section */
add_shortcode('matx-service-tab', 'matx_display_service_tabs');

function matx_display_service_tabs( $atts ){

	extract( shortcode_atts( array(
		'matx_service_ids'			=> '',
		'matx_service_thumb_pos'	=> '',
	), $atts ));

	$thumb_classes = array('col-sm-12 col-md-10 col-md-offset-1');

	if($matx_service_thumb_pos == 'yes') {
		$thumb_classes[]= 'alter-service-image';
	}

	$service_posts = explode(',', $matx_service_ids);

	$html = ''; ob_start(); ?>

	<div class="service-tabs service-tabv2" data-action="count-up">
		<div class="mdl-tabs mdl-js-tabs mdl-js-ripple-effect">
			<div class="row">
				<div class="<?php echo esc_attr(implode(' ', $thumb_classes) ); ?>">
					<div class="text-center">
						<div class="mdl-tabs__tab-bar matx-service-tabbar mdl-shadow--2dp">
							<?php 
								$i = 0;
								foreach ($service_posts as $tabid) {
									$i++;
									echo do_shortcode('[matx-service-tabmenu count="'.$i.'" id="'.$tabid.'"]' );
								}
							?>
						</div>
					</div>
					<div class="matx-tabpanel-wrap" >
						<?php
							$i = 0;
							foreach ( $service_posts as $tabid ) {
								$i++;
								echo do_shortcode('[matx-service-content count="'.$i.'" id="'.$tabid.'"]' );
							}
						?>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php $result = ob_get_contents(); $html .= $result; ob_get_clean();

	return $html;
}



/* video pop up */
add_shortcode('matx-social-video', 'matx_display_social_video' );

function matx_display_social_video($atts) {

	extract( shortcode_atts( array(
		'matx_video_url'			=> '',
		'matx_video_icon'			=> '',
		'matx_video_text_before'	=> '',
		'matx_video_text_after'		=> '',
	), $atts ) );

	$html  = '';

	$icon_class = ($matx_video_icon) ? $matx_video_icon : 'zmdi zmdi-play';

	if( $matx_video_url ) : ob_start(); ?>
		<div class="text-center video-dialog">
			<?php echo ($matx_video_text_before) ? esc_html( $matx_video_text_before) : ''; ?>
				<a href="<?php echo esc_url( $matx_video_url ); ?>" class="show-video mdl-button mdl-js-button mdl-button--fab mdl-js-ripple-effect btn-highlight"><i class="<?php echo esc_attr($icon_class); ?>"></i></a>
			<?php echo ($matx_video_text_after) ? esc_html($matx_video_text_after ) : ''; ?> 
		</div>
	<?php $result = ob_get_contents(); $html .= $result; ob_get_clean(); endif;

	return $html;
}



/* Map */
add_shortcode('matx-map', 'matx_display_map_section');

function matx_display_map_section($atts){

	extract( shortcode_atts( array(
		'map_button_text'		=> '',
		'map_button_close'		=> '',
		'map_latitude'			=> '',
		'map_longitude'			=> '',
		'map_zoom_lavel'		=> '',
		'map_marker_title'		=> '',
		'map_marker_text'		=> '',
	), $atts ) );


	$site_url = get_template_directory_uri();

	$randomID = function_exists('matx_random_id') ? matx_random_id(4) : '';
	
	$token = wp_generate_password(6, false, false);

	$map_data = array(
		'ID'				=> $randomID,
		'siteURL'			=> $site_url,
		'latitude'			=> $map_latitude,
		'longitude'			=> $map_longitude,
		'zoom'				=> $map_zoom_lavel,
		'markerTitle'		=> $map_marker_title,
		'markerDes'			=> $map_marker_text
	);

	$gmap_api_key = get_theme_mod( 'gmap_api_key', '' );


	$open_text = $map_button_text ? esc_html($map_button_text) : esc_html__( 'LOCATE US ON THE MAP', 'matx');
	$close_text = $map_button_close ? esc_html($map_button_close) : esc_html__( 'CLOSE THE MAP', 'matx');

	if( ! wp_script_is( 'matx_map_js' , 'enqueued' )) {

		wp_register_script('gmap_api', '//maps.google.com/maps/api/js?key='.$gmap_api_key, array(), null , true);
		wp_register_script('matx_map_js', get_template_directory_uri().'/assets/js/custom/map.js', array('jquery'), 1 , true); 

		if($gmap_api_key) {
			wp_enqueue_script('gmap_api');
			wp_enqueue_script('matx_map_js');
		}
	}


	wp_localize_script('matx_map_js', 'mapSettingsObj_'.$token, $map_data );

	$html = '';

	ob_start(); if($gmap_api_key) : ?>

	<div id="matxMapWrap-<?php echo $randomID; ?>" data-token="<?php echo esc_attr($token); ?>" class="text-center map-content-start">
		<div class="map-buttons">
			<button type="button" id="map-open<?php echo $randomID; ?>" class="btn-active btn btn-block btn-tranparent btn-animated from-top zmdi zmdi-chevron-down">
				<span><?php echo $open_text; ?></span>
			</button>
			<button type="button" id="map-close<?php echo $randomID; ?>" class="btn btn-block btn-tranparent btn-animated from-bottom zmdi zmdi-chevron-up">
				<span><?php echo $close_text; ?></span>
			</button>
		</div>
		<div class="map-wrapper">
			<div id="mapid-<?php echo $randomID; ?>" class="map-container"></div>
		</div>
	</div>

	<?php

		else : 

		echo '<div class="section-title text-center">To active Map, please enter a valid Google Map API key in customizer setting</div>';
	
	endif;

	$result = ob_get_contents(); $html .= $result; ob_get_clean();

	return $html;
}



/* Email subscription form */

add_shortcode('matx-newsletter', 'matx_newsletter_subscription');

function matx_newsletter_subscription($atts){

	extract(shortcode_atts( array(
		'nl_shortcode'		=> '',
		'nl_from_title'		=> '',
	), $atts ));

	$wrapper_class = array('clearfix newsletter-form');

	if($nl_shortcode) {
		$wrapper_class[] = $nl_shortcode;
	}


	$title  = ($nl_from_title) ? esc_html($nl_from_title): esc_html__( 'NEWSLETTER', 'matx' );;

	$html = ''; ob_start(); ?>

	<div class="clearfix newsletter newsletter-content-start">
		<div class="clearfix col-sm-12 col-md-offset-1 col-md-11 col-lg-offset-2 col-lg-8 padding-0-0">
			<div class="section-heading">
				<h2 class="section-title"><?php echo $title; ?></h2>
			</div>
			<div class="<?php echo esc_attr(implode(' ', $wrapper_class)); ?>">

				<?php if( $nl_shortcode && shortcode_exists( 'mc4wp_form' )){
					
					echo do_shortcode( '[mc4wp_form id="'.$nl_shortcode.'"]' );
				} else {
					
					echo '<div class="section-heading" style="width:100%;"><h2 class="section-title">'. esc_html__( 'Active recommended pluign', 'matx') .'</h2></div>';
				} ?>

			</div>
		</div>
	</div>

	<?php $result = ob_get_contents(); $html .= $result; ob_get_clean();

	return $html;
}



/* Brand logo slider */
add_shortcode('matx-brand-logo', 'matx_display_brand_slider' );

function matx_display_brand_slider($atts){

	extract(shortcode_atts( array(
		'matx_brand_slider_img'	=> ''
	), $atts ));

	$brandlogos = explode(',', $matx_brand_slider_img); 
	
	$html = '';

	$html .= '<div class="slider-items client-slider styled-paginantion colorsch-white" data-action="clientSlider">';

		if($brandlogos) {

			foreach ($brandlogos as $attachment_id) {

				$html .= '<div class="col-sm-3">';
					$html .= '<div class="single-clients">';

						$html .= wp_get_attachment_image( $attachment_id, 'brand-slider' );

					$html .= '</div>';
				$html .= '</div>';
			}
		}

	$html .= '</div>';

	return $html;
}



/* Portfolio grid */
add_shortcode('matx-portfolio', 'matx_display_protfolio' );

function matx_display_protfolio($atts){

	extract(shortcode_atts( array(
		'matx_pf_numpost'			=> '',
		'matx_pf_ajax_numpost'		=> '',
		'matx_all_edit'				=> '',
		// 'matx_portfolio_filter'		=> '', 
		'matx_pf_cat'				=> '',
		'btn_text'					=> '',
		'matx_portfolio_box'		=> '',
		'matx_portfolio_cols'		=> 'col_3',
	), $atts));


	$load_more_portfolio = ($matx_pf_ajax_numpost) ? $matx_pf_ajax_numpost : 3;

	/* get selected portfolio category */
	$selected_terms = explode(',', $matx_pf_cat);

	$selected_terms_data = array();

	foreach ($selected_terms as $id ) {
		$selected_terms_data[] = get_term_by('id', $id, 'portfolio-category');
	}

	$selected_terms_data = array_filter($selected_terms_data);

	$args = array(
		'post_type'        => 'matx-portfolio',
		'posts_per_page'   => ( $matx_pf_numpost ) ? $matx_pf_numpost : 6,
		'orderby'          => 'date',
		'order'            => 'DESC',
		'post_status'      => 'publish'
	);

	if( $selected_terms_data ){

		$selected_pf_term_id = array();

		foreach ($selected_terms_data as $term_data) {
			$selected_pf_term_id[] = $term_data->term_id;
		}

		$args['tax_query'] = array(
			array(
				'taxonomy' 			=> 'portfolio-category',
				'field' 			=> 'id',
				'terms' 			=> $selected_pf_term_id,
				'include_children' 	=> true,
				'operator' 			=> 'IN'
			)
		);
	}
	
	$query = new WP_Query( $args ); 

	if( !wp_script_is( 'matx-portfolio-js', 'enqueued' ) ){

		wp_register_script('matx-portfolio-js', get_template_directory_uri(). '/assets/js/custom/portfolio.js', array('jquery'), 1 , true);
		wp_enqueue_script('matx-portfolio-js');

		wp_localize_script( 'matx-portfolio-js', 'portfolioData', array( 'url' 	=> admin_url('admin-ajax.php') ));
	}

	$box_wrapper_class = array($matx_portfolio_cols.'-wrap', 'clearfix', 'protfolio-items');

	if( $matx_portfolio_box == 'pf_box_2') {

		$box_wrapper_class[] = 'portfolio-box-style-2';

	} elseif( $matx_portfolio_box == 'pf_box_3') {

		$box_wrapper_class[] = 'portfolio-box-style-3';

	} else {
		
		$box_wrapper_class[] = 'portfolio-box-style-1';
	}

	$box_class = array('col-xs-6', 'col-sm-4');

	switch ($matx_portfolio_cols) {

		case 'col_4':
			$box_class[] = 'col_4 col-md-3';
		break;

		case 'col_4_lessspec':
			$box_class[] = 'col_4_lessspec col-md-3';
			$box_wrapper_class[] = 'less-spacing-col';
		break;

		case 'col_4_nospec':
			$box_class[] = 'col_4_nospec col-md-3';
			$box_wrapper_class[] = 'no-spacing-col';
		break;

		case 'col_3_lessspec':
			$box_class[] = 'col_3_lessspec';
			$box_wrapper_class[] = 'less-spacing-col';
		break;

		case 'col_3_nospec':
			$box_class[] = 'col_3_nospec';
			$box_wrapper_class[] = 'no-spacing-col';
		break;
		
		default:
			$box_class[] = 'col_3';
		break;
	}

	$box_class[] = 'single-portfolio';


	$html = '';

	ob_start();
	
	if( $query->have_posts() ) : ?>
		  
	<div class="section-main-content-start" data-loadmore="<?php echo esc_attr( $load_more_portfolio ); ?>" data-action="portfolio" data-portfolio-style="<?php echo esc_attr( $matx_portfolio_cols ); ?>">

		<div class="text-center portfolio-category-wrap">
			<ul class="clearfix portfolio-category mdl-shadow--2dp">
				<?php 
					$matx_all_edit = ($matx_all_edit) ? esc_html($matx_all_edit) : esc_html__('all', 'matx');

					echo '<li class="filter active" data-target="*">'. $matx_all_edit.'</li>';

					if( $selected_terms_data ){
						foreach ( $selected_terms_data as $term_data ) {
							echo '<li class="filter" data-target=".'.esc_attr( $term_data->slug ).'">'.esc_html( $term_data->name ).'</li>';
						}
					} else {
						$pcats = get_terms( 'portfolio-category');
						foreach( $pcats as $pcat ) {
							echo '<li class="filter" data-target=".'.esc_attr( $pcat->slug ).'">'.esc_html( $pcat->name ).'</li>';
						}
					}
				?>
			</ul>
		</div>
		
		<div class="protfolio-items-wrap">

			<div class="<?php echo esc_attr( implode(' ', $box_wrapper_class) ); ?>">

				<?php while( $query->have_posts()) : $query->the_post();

					$prefix = '_matx_portfolio_';
					$portfolio_action = get_post_meta( get_the_id(), $prefix.'is_external_url', true );
					$subtitle = get_post_meta( get_the_id(), $prefix.'popup_stitle', true );
					$thumbnail_src = get_the_post_thumbnail_url( get_the_id(), 'full' );


					$box_class_category = function_exists('get_matx_terms') ? strtolower(get_matx_terms('portfolio-category')) : '';

					?>

					<div data-portfolio-id="portfolio-<?php the_id(); ?>" class="<?php echo esc_attr( implode(' ', $box_class) ).' '.esc_attr($box_class_category ); ?>">
						<div class="portfolio-item">
							<a <?php if( $portfolio_action == 'pf_ac_single') {
									
									echo ' href="'.esc_url( get_permalink( get_the_id() ) ).'"';

								} elseif( $portfolio_action == 'pf_ac_light') {
 
									echo ' href="'.esc_url( $thumbnail_src ).'" class="portfolio-default-popup"';

								} else {

									echo ' href="'.esc_url( admin_url( 'admin-ajax.php' ).'?action=matx_portfolio_details&pid='.get_the_id() ).'" class="portfolio-custom-popup"';
								} ?>>
								<div class="protfolio-image">
									<?php echo has_post_thumbnail(get_the_id()) ? get_the_post_thumbnail( get_the_id(), 'matx-portfolio-thumbnail') : ''; ?>
									<div class="pf-overlay"><i class="zmdi zmdi-center-focus-strong"></i></div>
								</div>
								<div class="portfolio-meta">
									<i class="zmdi zmdi-plus-circle"></i>
									<h3 class="portfolio-title"><?php the_title(); ?></h3>
									<div class="portfolio-subtitle"><?php echo esc_html($subtitle); ?></div>
								</div>
								<div class="pf-overlay"></div>
							</a>
						</div>
					</div> 
				<?php endwhile; ?>
			</div>
		</div>
		<div data-action="portfolioInitItem" class="ajax-hidden-div" style="height: 1px; overflow: hidden;"></div>
		<div class="text-center load-portfolio wow fadeInUpSmall" data-wow-duration="1s">
			<button data-action="portfolioLoadItem" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect btn-default btn-highlight"><?php  echo $btn_text ? $btn_text :esc_html__('LOAD MORE', 'matx'); ?></button>
		</div>
	</div>

	<?php endif; wp_reset_postdata();

	$result = ob_get_contents(); $html .= $result; ob_get_clean();

	return $html;
}


/* Blog post grid */
add_shortcode('matx-blogpost-grid', 'matx_front_page_blog' );

function matx_front_page_blog($atts){

	extract(shortcode_atts( array(
		'matx_blog_numpost' 		=> '',
		'matx_blog_grid_style' 		=> '',
		'matx_post_catlist' 		=> '',
		'matx_post_formatlists' 	=> '',
	), $atts ));


	$post_format_default = array( 'post-format-quote', 'post-format-audio', 'post-format-gallery', 'post-format-image', 'post-format-video');
 
	$post_format_slug = explode( ",", $matx_post_formatlists );
	$post_format_slug = array_filter( $post_format_slug );

	$args = array(
		'post_type'        	=> 'post',
		'posts_per_page'   	=> ( (int) $matx_blog_numpost ) ? (int) $matx_blog_numpost : 3,
		'orderby'          	=> 'date',
		'order'            	=> 'DESC',
		'post_status'      	=> 'publish',
	);

	if ( $matx_post_catlist ) {
		$args['cat'] = $matx_post_catlist;
	}

	if ( $post_format_slug ) {
		
		if( $post_format_slug[0] == 'post-format-standard' ) {

			$terms_arr = array_diff( $post_format_default, $post_format_slug );

			$args['tax_query'] = array(
				array(
					'taxonomy' 	=> 'post_format',
					'field' 	=> 'slug',
					'terms' 	=> $terms_arr,
					'operator' 	=> 'NOT IN'
				)
			);

		} else {

			$args['tax_query'] = array(
				array(
					'taxonomy' 			=> 'post_format',
					'field' 			=> 'slug',
					'terms' 			=> $post_format_slug,
					'include_children' 	=> true,
					'operator' 			=> 'IN'
				)
			);
		}
	}

	if( $matx_blog_grid_style == 'style_two' ){

		$masonry_attr 			= 'blog-masonry-grid';
		$posts_wrapper_class 	= 'row blog-content-start blog-layout-masonry'; 
		$single_post_class 		= 'col-xxs-12 col-xs-6 col-sm-6 col-md-4 front-blog-post'; 

	} else {
		
		$masonry_attr 			= 'blog-basic-grid';
		$posts_wrapper_class 	= 'row blog-content-start blog-basic-masonry'; 
		$single_post_class 		= 'front-blog-post col-sm-4'; 
		
	}
	

	$blog_postq = new WP_Query( $args );

	$html = '';

	if( $blog_postq->have_posts()) : 

	$html .= '<div class="'.esc_attr( $posts_wrapper_class ).'" data-action="'.esc_attr( $masonry_attr ).'">';

		while( $blog_postq->have_posts() ) : $blog_postq->the_post();
 
	$html .= '<div class="'.esc_attr( $single_post_class ).'">';

		ob_start();

		get_template_part( 'template-parts/content-post-frontpage', get_post_format() );

		$result = ob_get_contents();  

		ob_end_clean(); 

		$html .=  $result;

		$html .= '</div> ';

	endwhile;

	$html .= '</div> '; // end .blog-content-start

	endif; wp_reset_postdata();

	return $html;
}



/* Twitter slider */
add_shortcode('matx-twitter-slider', 'matx_twitter_slider' );

function matx_twitter_slider($atts){

	extract(shortcode_atts( array(
		'num_tweet'			=> '',
		'ts_duration'		=> '',
		'ts_page_duration'	=> '',
		'tslider_tstyle'	=> '',
		'ts_color_scheme'	=> ''
	), $atts));

	$randomID = function_exists('matx_random_id') ? matx_random_id(4) : '';

	$token = wp_generate_password(6, false, false);

	
	$tweetslid_settings = array(
		'token'				=> $token,
		'num_tweet'			=> $num_tweet,
		'ts_duration'		=> $ts_duration,
		'ts_page_duration'	=> $ts_page_duration,
		'tslider_tstyle'	=> $tslider_tstyle,
		'ts_color_scheme'	=> $ts_color_scheme
	);

	$tc_key 	= get_theme_mod('twitter_consumer_key', '' );
	$tc_secret 	= get_theme_mod('twitter_consumer_secret', '' );
	$ta_token 	= get_theme_mod('twitter_access_token', '' );
	$ta_secret 	= get_theme_mod('twitter_access_secret', '' );

	if( ($tc_key && $tc_secret  && $ta_token && $ta_secret ) == '' ) {
		$tweetslid_settings['twitter_config'] = 'empty';
	}

	if( ! wp_script_is( 'tweet-slider', 'enqueued' )) {

		wp_register_script('tweet-slider', get_template_directory_uri().'/assets/js/custom/twitter-slider.js', array('jquery'), 1 , true);

		wp_enqueue_script('tweet-slider');
		
		$tweet_config = array(

			'tweeter_api_url' => admin_url( 'admin-ajax.php' ).'?action=matx_twitter_auth',
		);

		wp_localize_script('tweet-slider', 'twitterConfig', $tweet_config );
	}

	$data = json_encode( $tweetslid_settings );

	$html = '';
	$html .= '<div class="text-center">';
		$html .= '<div class="twitter-thumb wow fadeInDown" data-token="'.$token.'" data-wow-duration="1s">';
			$html .= '<i class="zmdi zmdi-twitter"></i>';
		$html .= '</div>';

		if( $ts_color_scheme == 'ts_ch_black'){

			$html .= '<div class="matx-tweet-slider slider-item tweets styled-paginantion colorsch-white tweetSlider" data-tweet-setting=\''.$data.'\'></div>';

		} else {
			
			$html .= '<div class="matx-tweet-slider slider-item tweets styled-paginantion colorsch-black tweetSlider" data-tweet-setting=\''.$data.'\'></div>';
		}
		
	$html .= '</div>';

	return $html;
}



/* fun fact */
add_shortcode('matx-funfact-count', 'matx_funfact_counter' );

function matx_funfact_counter($atts){
	extract( shortcode_atts( array(
		'matx_ff_title'		=> '',
		'matx_ff_value'		=> '',
		'matx_ff_color'		=> '',
		'matx_ff_speed'		=> 1500
	), $atts ));

	$c_title = ( !empty( $matx_ff_title )) ? $matx_ff_title : '';
	$c_value = ( !empty( $matx_ff_value )) ? $matx_ff_value : '';

	$wrapper_class = array('funfact single-fact');

	$wrapper_class[] = ( $matx_ff_color == 'ff_color_black') ? 'color-dark' : 'color-light';

	$html = ''; ob_start(); ?>

	<div class="<?php echo esc_attr(implode(' ', $wrapper_class)); ?>" data-action="count-up">
		<?php echo ($c_value) ? '<div class="fact-count countNumb" data-from="1" data-to="'.esc_attr($c_value).'">'.esc_html( $c_value ).'</div>' : ''; ?>
		<?php echo ($c_title) ? '<div class="fact">'.esc_html( $c_title ).'</div>' : ''; ?>
	</div>

	<?php $result = ob_get_contents(); $html .= $result; ob_get_clean();

	return $html;
}



/* Common slider */
add_shortcode( 'matx_common_slider', 'matx_common_slider_cb' );

function matx_common_slider_cb($atts, $content = 'null'){

	extract( shortcode_atts( array(
		'slider_style'	=> '',
		'single_item' 	=> '',
		'desktop' 		=> '',
		'small_desktop' => '',
		'tablet' 		=> '',
		'small_tablet' 	=> '',
		'mobile' 		=> '',
		'auto_play' 	=> '',
		'stop_on_hover' => '',
		'el_class'		=> '',

	), $atts ));

	$wrapper_class = array();
	$left_nav = 'mdl-button mdl-js-button mdl-js-ripple-effect left-arrow wow fadeInLeft';
	$right_nav = 'mdl-button mdl-js-button mdl-js-ripple-effect right-arrow wow fadeInRight';
	 

	$token = wp_generate_password(4, false, false);

	$CommonSliderData = array(
		'sliderStyle'	=> $slider_style,
		'singleItem' 	=> $single_item,
		'desktop' 		=> $desktop,
		'smallDesktop' 	=> $small_desktop,
		'tablet' 		=> $tablet,
		'smallTablet' 	=> $small_tablet,
		'mobile' 		=> $mobile,
		'autoPlay' 		=> $auto_play,
		'stopOnHover' 	=> $stop_on_hover,
	);

	if( ! wp_script_is( 'matx-common-slider-js' , 'enqueued' )) {
		wp_register_script(
		'matx-common-slider-js',
		get_template_directory_uri().'/assets/js/custom/common-slider.js',
		array('jquery'), 1 , true); 
		wp_enqueue_script('matx-common-slider-js');		
	}

	wp_localize_script('matx-common-slider-js', 'CommonSlider'.$token, $CommonSliderData );

	$html = '';

	$html .= '<div class="matx-common-slider-wrap">';
		$html .= '<div class="matx-common-slider styled-paginantion colorsch-white" data-slider-config=\''.json_encode($CommonSliderData).'\' data-action="commonSlider">';

			ob_start();

				echo do_shortcode( $content );

				$result = ob_get_contents();  

			ob_end_clean(); 

			$html .=  $result;
		$html .= '</div>';

		$html .= '<div class="clearfix matx-common-slider-nav slider-cntrl">';
			$html .= '<a href="#" class="'.$left_nav.'" data-wow-duration="1s"><i class="zmdi zmdi-chevron-left"></i></a>';
			$html .= '<a href="#" class="'.$right_nav.'" data-wow-duration="1s"><i class="zmdi zmdi-chevron-right"></i></a>';
		$html .= '</div>';
	$html .= '</div>';

	return $html;
}


add_shortcode('matx_space','matx_blank_space_cb' );

function matx_blank_space_cb($atts){

	extract(shortcode_atts( array(
		'desktop'		=> '',
		'notebook'		=> '',
		'tablet'		=> '',
		'phone'			=> '',

	), $atts ));

	$desktop 	= $desktop ? $desktop : '';
	$notebook 	= $notebook ? $notebook : '';
	$tablet 	= $tablet ? $tablet : '';
	$phone 		= $phone ? $phone : '';


	$wrapper_class = array('matx-blank-space');

	if($desktop) {
		$wrapper_class[] = 'has-desktop-space';
	}

	if($notebook) {
		$wrapper_class[] = 'has-notebook-space';
	}

	if($tablet) {
		$wrapper_class[] = 'has-tablet-space';
	}

	if($phone) {
		$wrapper_class[] = 'has-phone-space';
	}
 

	$html = '';

	ob_start(); ?>

	<div class="<?php echo esc_attr(implode(' ', $wrapper_class)); ?>">
		<?php 
			echo $desktop ? '<div class="matx-space-content matx-space-desktop-large" style="height: '.esc_attr($desktop).' "></div>' : '';
			echo $notebook ?  '<div class="matx-space-content matx-space-desktop-small" style="height: '.esc_attr($notebook).'"></div>' : '';
			echo $tablet ?  '<div class="matx-space-content matx-space-tablet" style="height: '.esc_attr($tablet).'"></div>' : '';
			echo $phone ?  '<div class="matx-space-content matx-space-phone" style="height: '.esc_attr($phone).'"></div>' : '';
		?>
	</div>

	<?php  $o = ob_get_contents(); $html .= $o; ob_get_clean();

	return $html;

}


add_shortcode('matx_image_carousel', 'matx_image_carousel_cb' );

function matx_image_carousel_cb($atts){

	extract(shortcode_atts( array(
		'images'		=> '',
		'pagination'	=> '',
		'color'			=> '',
		'autoplay'		=> '',
		'el_class'		=> '',
	), $atts ));

	$image_ids = explode(',', $images );

	$brief_thumbs = '';
    $settings = array();
	$wrapper_class = array('matx-image-carousel styled-paginantion');


	switch ($pagination) {

		case 'bn':
			$wrapper_class[] = 'enable-navigation-pagination';
		break;

		case 'n':
			$wrapper_class[] = 'enable-navigation-only';
		break;
		
		default:
			$wrapper_class[] = 'enable-pagination-only';
		break;
	}

    switch ($color) {
    	case 'white':
			$wrapper_class[] = 'image-carousel-light';
		break;
    	
    	default:
			$wrapper_class[] = 'image-carousel-dark';
		break;
    }

    if($el_class) {
		$wrapper_class[] = $el_class;
    }

    if($pagination == '') {	
    	$settings['p'] = true;
    }

    if($pagination == 'bn') {
    	$settings['p'] = true;
    	$settings['n'] = true;
    }

    if($pagination == 'n') {
    	$settings['n'] = true;
    }

    if($autoplay == 'off') {
    	$settings['autoplay'] = 'false';
    }

    $settings = json_encode($settings);

	$html = '';

	ob_start(); ?>

		<div class="<?php echo esc_attr(implode(' ', $wrapper_class) ); ?>" data-settings="<?php echo esc_attr( $settings ); ?>" data-action="matxImageCarousel">
			<div class="matx-image-carousel-base">
				<?php
					if($image_ids) {
						foreach ( $image_ids as $ID ) {
							echo wp_get_attachment_image( $ID, 'matx-brief-slider' );
						}
					}
				?>
			</div>

			<?php if( $pagination != '' && count($image_ids) > 1 ) : ?>

				<div class="clearfix matx-image-carousel-nav">
					
					<a href="#" class="mdl-button mdl-js-button mdl-js-ripple-effect icon-arrow left-arrow wow fadeInLeft" data-wow-duration="1s">
						<i class="zmdi zmdi-chevron-left"></i>
					</a>
					<a href="#" class="mdl-button mdl-js-button mdl-js-ripple-effect icon-arrow right-arrow wow fadeInRight" data-wow-duration="1s">
						<i class="zmdi zmdi-chevron-right"></i>
					</a>
				</div>

			<?php endif; ?>
			
		</div>

		<?php
		
	$result = ob_get_contents(); $html .= $result; ob_get_clean();
	return $html;
	
}

add_shortcode('matx_year', 'matx_get_current_date_cb' );

function matx_get_current_date_cb(){
	return date('Y');
}
