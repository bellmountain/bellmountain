<?php
    /**
     * Your Twitter App Info
     */

    $tw_consumer_key    = get_theme_mod( 'twitter_consumer_key', '' );
    $tw_consumer_secret = get_theme_mod( 'twitter_consumer_secret', '' );
    $tw_access_token    = get_theme_mod( 'twitter_access_token', '' );
    $tw_access_secret   = get_theme_mod( 'twitter_access_secret', '' );
    
    // Consumer Key
    define('CONSUMER_KEY',      $tw_consumer_key);
    define('CONSUMER_SECRET',   $tw_consumer_secret);

    // User Access Token
    define('ACCESS_TOKEN',  $tw_access_token);
    define('ACCESS_SECRET', $tw_access_secret);
    
    // Cache Settings
    define('CACHE_ENABLED', false);
    define('CACHE_LIFETIME', 3600); // in seconds
    define('HASH_SALT', md5(dirname(__FILE__)));