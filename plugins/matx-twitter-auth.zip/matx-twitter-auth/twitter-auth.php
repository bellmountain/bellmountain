<?php

/**
 * Plugin Name: Matx Twitter Auth
 * Plugin URI: http://themeforest.net/user/coderpixel
 * Description: It enable voting system and count up vote for every single portfolio item.
 * Version: 1.0.0
 * Author: Coderpixel
 * Author URI: http://themeforest.net/user/coderpixel
 */

define( 'PLUGIN_DIR', plugin_dir_path(__FILE__) );


/**
 * twitter api
 */
add_action( 'wp_ajax_nopriv_matx_twitter_auth', 'matx_twitterapi_auth' );
add_action( 'wp_ajax_matx_twitter_auth', 'matx_twitterapi_auth' );

function matx_twitterapi_auth() {

	require_once( PLUGIN_DIR . 'twitter-config/twitteroauth/twitteroauth.php' );
	require_once( PLUGIN_DIR . 'twitter-config/config.php' );
	require_once( PLUGIN_DIR . 'twitter-config/tweet.php' );

	wp_die();
}